<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

function software_filing_unique_submission_number(): string
{
    return 'CHADMIN-' . gmdate('YmdHis') . '-' . bin2hex(random_bytes(4));
}

function xml_escape(string $value): string
{
    return htmlspecialchars($value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

function software_filing_md5_credential(string $value): string
{
    $value = trim($value);

    if ($value === '') {
        return '';
    }

    if (preg_match('/^md5#[0-9a-f]{32}$/i', $value)) {
        return 'md5#' . strtolower(substr($value, 4));
    }

    return 'md5#' . strtolower(md5($value));
}

function software_filing_base64_from_string(string $content): string
{
    if ($content === '') {
        throw new RuntimeException('Document content is empty.');
    }

    return base64_encode($content);
}

function software_filing_base64_from_file(string $path): string
{
    $path = trim($path);

    if ($path === '' || !is_file($path) || !is_readable($path)) {
        throw new RuntimeException('Document file is missing or unreadable: ' . $path);
    }

    $content = file_get_contents($path);

    if (!is_string($content) || $content === '') {
        throw new RuntimeException('Failed to read document file: ' . $path);
    }

    return base64_encode($content);
}

function build_govtalk_envelope_base(
    string $class,
    string $bodyXml,
    array $options = []
): array {
    $transactionId = trim((string) ($options['transaction_id'] ?? ''));
    $transactionId = $transactionId !== '' ? $transactionId : software_filing_unique_submission_number();

    $formTypeKey = trim((string) ($options['form_type_key'] ?? ''));
    $senderEmail = trim((string) ($options['sender_email'] ?? ''));
    $function = trim((string) ($options['function'] ?? 'submit'));
    $product = trim((string) ($options['product'] ?? 'CHADMIN-SPLIT-TEST'));
    $productVersion = trim((string) ($options['product_version'] ?? '1.0'));

    $presenterId = software_filing_presenter_id();
    $presenterCode = software_filing_presenter_code();

    if ($presenterId === '' || $presenterCode === '') {
        throw new RuntimeException('Software filing presenter credentials are missing.');
    }

    $senderId = software_filing_md5_credential($presenterId);
    $authValue = software_filing_md5_credential($presenterCode);
    $gatewayTest = software_filing_is_test_mode() ? '1' : '0';

    $keysXml = '';
    if ($formTypeKey !== '') {
        $keysXml .= '<Key Type="FormType">' . xml_escape($formTypeKey) . '</Key>';
    }

    $xml =
        '<?xml version="1.0" encoding="UTF-8"?>'
        . '<GovTalkMessage xmlns="http://www.govtalk.gov.uk/CM/envelope">'
        . '<EnvelopeVersion>2.0</EnvelopeVersion>'
        . '<Header>'
        . '<MessageDetails>'
        . '<Class>' . xml_escape($class) . '</Class>'
        . '<Qualifier>request</Qualifier>'
        . '<Function>' . xml_escape($function) . '</Function>'
        . '<TransactionID>' . xml_escape($transactionId) . '</TransactionID>'
        . '<GatewayTest>' . $gatewayTest . '</GatewayTest>'
        . '</MessageDetails>'
        . '<SenderDetails>'
        . '<IDAuthentication>'
        . '<SenderID>' . xml_escape($senderId) . '</SenderID>'
		. '<Authentication>'
		. '<Method>clear</Method>'
		. '<Value>' . xml_escape($authValue) . '</Value>'
		. '</Authentication>'
        . '</IDAuthentication>'
        . ($senderEmail !== '' ? '<EmailAddress>' . xml_escape($senderEmail) . '</EmailAddress>' : '')
        . '</SenderDetails>'
        . '</Header>'
        . '<GovTalkDetails>'
        . '<Keys>' . $keysXml . '</Keys>'
        . '<TargetDetails>'
        . '<TargetOrganisation>CompaniesHouse</TargetOrganisation>'
        . '</TargetDetails>'
        . '<ChannelRouting>'
        . '<Channel>'
        . '<URI>http://www.govtalk.gov.uk/CM/gateway</URI>'
        . '<Product>' . xml_escape($product) . '</Product>'
        . '<Version>' . xml_escape($productVersion) . '</Version>'
        . '</Channel>'
        . '</ChannelRouting>'
        . '</GovTalkDetails>'
        . '<Body>' . $bodyXml . '</Body>'
        . '</GovTalkMessage>';

    return [
        'transaction_id' => $transactionId,
        'xml' => $xml,
    ];
}