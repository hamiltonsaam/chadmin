<?php
declare(strict_types=1);

function get_todo_companies(?string $categoryFilter = null, int $page = 1, int $perPage = 7): array
{
    $companies = get_companies(false);
    $result = [];

    foreach ($companies as $company) {
        // Hide green / all-clear companies
        if (dashboard_company_color($company) === 'name-green') {
            continue;
        }

        // Category filter
        if ($categoryFilter !== null && $categoryFilter !== '') {
            $companyCategory = trim((string) ($company['category'] ?? ''));

            if ($companyCategory !== $categoryFilter) {
                continue;
            }
        }

        $result[] = $company;
    }

    // Sort by dashboard risk priority, then company name
    usort($result, static function (array $a, array $b): int {
        $priorityA = dashboard_company_color_priority($a);
        $priorityB = dashboard_company_color_priority($b);

        if ($priorityA !== $priorityB) {
            return $priorityA <=> $priorityB;
        }

        $nameA = strtoupper(company_display_name_with_label($a));
        $nameB = strtoupper(company_display_name_with_label($b));

        return strcmp($nameA, $nameB);
    });

    // Pagination
    $page = max(1, $page);
    $perPage = max(1, min($perPage, 50));

    $total = count($result);
    $pages = max(1, (int) ceil($total / $perPage));

    if ($page > $pages) {
        $page = $pages;
    }

    $offset = ($page - 1) * $perPage;
    $rows = array_slice($result, $offset, $perPage);

    return [
        'rows'     => $rows,
        'total'    => $total,
        'page'     => $page,
        'per_page' => $perPage,
        'pages'    => $pages,
    ];
}

function get_todo_summary_counts(?string $categoryFilter = null): array
{
    $allCompanies = get_companies(false);

    if ($categoryFilter !== null && $categoryFilter !== '') {
        $allCompanies = array_filter($allCompanies, function ($c) use ($categoryFilter) {
            return trim((string) ($c['category'] ?? '')) === $categoryFilter;
        });
    }

    $counts = [
        'total'        => count($allCompanies),
        'brown'        => 0,
        'red'          => 0,
        'due_soon'     => 0,
        'ok'           => 0,
        'accounts'     => 0,
        'confirmation' => 0,
    ];

    foreach ($allCompanies as $company) {
        $color = dashboard_company_color($company);

        switch ($color) {
            case 'name-brown':
                $counts['brown']++;
                break;

            case 'name-red':
                $counts['red']++;
                break;

            case 'name-yellow':
                $counts['due_soon']++;
                break;

            case 'name-green':
                $counts['ok']++;
                break;
        }

        $aLevel = due_level($company['accounts_due_date'] ?? null);
        if ($aLevel === 'red' || $aLevel === 'orange') {
            $counts['accounts']++;
        }

        $sLevel = due_level($company['confirmation_statement_due_date'] ?? null);
        if ($sLevel === 'red' || $sLevel === 'orange') {
            $counts['confirmation']++;
        }
    }

    return $counts;
}