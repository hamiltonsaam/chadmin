<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

try {
    $error = $_GET['error'] ?? '';
    if ($error !== '') {
        throw new RuntimeException('OAuth error: ' . $error);
    }

    $code = (string) ($_GET['code'] ?? '');
    $state = (string) ($_GET['state'] ?? '');

    if ($code === '' || $state === '') {
        throw new RuntimeException('Missing OAuth code or state.');
    }

    $companyNumber = handle_oauth_callback($state, $code);

    set_flash('Companies House filing access connected for ' . $companyNumber . '.');
    redirect_to('index.php?company=' . urlencode($companyNumber));
} catch (Throwable $e) {
    set_flash($e->getMessage(), 'error');
    redirect_to('index.php');
}