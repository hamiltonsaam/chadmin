<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

try {
    $action = (string) ($_GET['action'] ?? $_POST['action'] ?? '');
    $companyNumber = strtoupper(trim((string) ($_GET['company'] ?? $_POST['company_number'] ?? '')));

    if ($companyNumber === '') {
        throw new RuntimeException('Company number is required.');
    }

    if ($action === 'connect') {
        redirect_to(get_oauth_authorize_url($companyNumber));
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'submit_registered_office') {
        $result = submit_registered_office_change($companyNumber, $_POST);

        set_flash(
            'Registered office filing submitted. Transaction ID: ' . $result['transaction_id'],
            'ok'
        );
        redirect_to('filing_page.php?company=' . urlencode($companyNumber));
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'submit_registered_email') {
        $result = submit_registered_email_change(
            $companyNumber,
            (string) ($_POST['registered_email_address'] ?? '')
        );

        set_flash(
            'Registered email filing submitted. Transaction ID: ' . $result['transaction_id'],
            'ok'
        );
        redirect_to('filing_page.php?company=' . urlencode($companyNumber));
    }
} catch (Throwable $e) {
    set_flash($e->getMessage(), 'error');
    redirect_to('filing_page.php?company=' . urlencode((string) ($_GET['company'] ?? $_POST['company_number'] ?? '')));
}

$flash = get_flash();
$companyNumber = strtoupper(trim((string) ($_GET['company'] ?? '')));
$company = get_company($companyNumber);
$oauthToken = $company ? get_oauth_token($companyNumber) : null;

if (!$company) {
    set_flash('Company not found in your dashboard.', 'error');
    redirect_to('index.php');
}

require __DIR__ . '/views/filing_page_view.php';